$dir = 'C:\Users\daniel joshua madrid\.gemini\antigravity\brain\3b4ab34b-cece-44d1-8582-2fc10734e7b0\.tempmediaStorage'
Get-ChildItem $dir | Sort-Object LastWriteTime -Descending | Select-Object -First 10 | ForEach-Object {
    Write-Host "$($_.LastWriteTime)  $($_.Length)  $($_.FullName)"
}

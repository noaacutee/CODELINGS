package com.example.codelings;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Menupage extends AppCompatActivity {

    private ImageButton btnStart;
    private ImageButton btnSettings;
    private ImageButton btnQuit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.menupage);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnStart = findViewById(R.id.btnStart);
        btnSettings = findViewById(R.id.btnSettings);
        btnQuit = findViewById(R.id.btnQuit);

        if (btnStart != null) {
            btnStart.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                android.content.Intent intent = new android.content.Intent(this, chooseyourlanguage.class);
                startActivity(intent);
            });
        }

        if (btnSettings != null) {
            btnSettings.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                android.content.Intent intent = new android.content.Intent(this, settingspage.class);
                startActivity(intent);
            });
        }

        if (btnQuit != null) {
            btnQuit.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                finishAffinity();
            });
        }
    }
}

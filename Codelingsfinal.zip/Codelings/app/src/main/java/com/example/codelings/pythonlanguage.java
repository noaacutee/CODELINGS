package com.example.codelings;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class pythonlanguage extends AppCompatActivity {

    private ImageButton btnBack;
    private ImageButton btnLevel1;
    private ImageButton btnLevel2;
    private final int[] lockedButtonIds = new int[] {
        R.id.btnLevel3, R.id.btnLevel4, R.id.btnLevel5,
        R.id.btnLevel6, R.id.btnLevel7, R.id.btnLevel8, R.id.btnLevel9, R.id.btnLevel10
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.pythonlanguage);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnBack = findViewById(R.id.btnPythonBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                finish();
            });
        }

        // Level 1 (Always Unlocked)
        btnLevel1 = findViewById(R.id.btnLevel1);
        if (btnLevel1 != null) {
            btnLevel1.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                Intent intent = new Intent(this, level1.class);
                startActivity(intent);
            });
        }

        btnLevel2 = findViewById(R.id.btnLevel2);

        updateLevelsState();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateLevelsState();
    }

    private void updateLevelsState() {
        SharedPreferences prefs = getSharedPreferences("UserProfile", MODE_PRIVATE);
        int unlockedLevel = prefs.getInt("python_unlocked_level", 1);

        if (btnLevel2 != null) {
            if (unlockedLevel >= 2) {
                btnLevel2.setImageResource(R.drawable.btn_level_2_unlocked);
                btnLevel2.setContentDescription("Level 2: Comments (Unlocked)");
                btnLevel2.setOnClickListener(v -> {
                    SoundManager.getInstance(this).playClick(this);
                    Intent intent = new Intent(this, level2.class);
                    startActivity(intent);
                });
            } else {
                btnLevel2.setImageResource(R.drawable.btn_level_2);
                btnLevel2.setContentDescription("Level 2: Comments (Locked)");
                btnLevel2.setOnClickListener(v -> {
                    SoundManager.getInstance(this).playClick(this);
                    Toast.makeText(this, "Complete Level 1 to unlock Level 2!", Toast.LENGTH_SHORT).show();
                });
            }
        }

        final Class<?>[] levelClasses = new Class<?>[] {
                level3.class, level4.class, level5.class,
                level6.class, level7.class, level8.class, null, null
        };

        for (int i = 0; i < lockedButtonIds.length; i++) {
            final int levelNumber = i + 3;
            ImageButton btnLevel = findViewById(lockedButtonIds[i]);
            if (btnLevel != null) {
                if (unlockedLevel >= levelNumber && i < levelClasses.length && levelClasses[i] != null) {
                    final Class<?> targetClass = levelClasses[i];
                    btnLevel.setOnClickListener(v -> {
                        SoundManager.getInstance(this).playClick(this);
                        Intent intent = new Intent(this, targetClass);
                        startActivity(intent);
                    });
                } else {
                    btnLevel.setOnClickListener(v -> {
                        SoundManager.getInstance(this).playClick(this);
                        Toast.makeText(this, "Complete Level " + (levelNumber - 1) + " to unlock Level " + levelNumber + "!", Toast.LENGTH_SHORT).show();
                    });
                }
            }
        }
    }
}
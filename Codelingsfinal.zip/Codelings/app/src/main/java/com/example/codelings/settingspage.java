package com.example.codelings;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class settingspage extends AppCompatActivity {

    private EditText etProfileName;
    private ImageButton btnGenderMale, btnGenderFemale, btnGenderOther;
    private EditText etProfileAge;
    private ImageButton btnProfileActionButton;

    private SeekBar sliderMusic;
    private SeekBar sliderSfx;
    private ImageButton btnCredits;
    private ImageButton btnResetData;

    private String currentGender = "Male";
    private String savedName = "";
    private String savedGender = "Male";
    private int savedAge = 1;

    private boolean isEditMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.settingspage);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize UI components
        etProfileName = findViewById(R.id.etProfileName);
        btnGenderMale = findViewById(R.id.btnGenderMale);
        btnGenderFemale = findViewById(R.id.btnGenderFemale);
        btnGenderOther = findViewById(R.id.btnGenderOther);
        etProfileAge = findViewById(R.id.etProfileAge);
        btnProfileActionButton = findViewById(R.id.btnProfileActionButton);

        ImageButton btnSettingsBack = findViewById(R.id.btnSettingsBack);
        if (btnSettingsBack != null) {
            btnSettingsBack.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                finish();
            });
        }

        // Load profile data from SharedPreferences
        loadProfileData();

        // Gender button listeners
        btnGenderMale.setOnClickListener(v -> {
            SoundManager.getInstance(this).playClick(this);
            onGenderSelected("Male");
        });
        btnGenderFemale.setOnClickListener(v -> {
            SoundManager.getInstance(this).playClick(this);
            onGenderSelected("Female");
        });
        btnGenderOther.setOnClickListener(v -> {
            SoundManager.getInstance(this).playClick(this);
            onGenderSelected("Other");
        });

        // Text change listeners to detect edits
        TextWatcher editWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkIfModified();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        etProfileName.addTextChangedListener(editWatcher);
        etProfileAge.addTextChangedListener(editWatcher);

        // Clicking pencil or edit box enables editing and focuses input
        View.OnClickListener startEditNameListener = v -> {
            SoundManager.getInstance(this).playClick(this);
            if (!isEditMode) {
                setEditingEnabled(true);
                btnProfileActionButton.setImageResource(R.drawable.btn_save_changes_green);
            }
            etProfileName.requestFocus();
            etProfileName.setSelection(etProfileName.getText().length());
        };
        View.OnClickListener startEditAgeListener = v -> {
            SoundManager.getInstance(this).playClick(this);
            if (!isEditMode) {
                setEditingEnabled(true);
                btnProfileActionButton.setImageResource(R.drawable.btn_save_changes_green);
            }
            etProfileAge.requestFocus();
            etProfileAge.setSelection(etProfileAge.getText().length());
        };

        View ivEditNamePencil = findViewById(R.id.ivEditNamePencil);
        if (ivEditNamePencil != null) ivEditNamePencil.setOnClickListener(startEditNameListener);
        View ivEditAgePencil = findViewById(R.id.ivEditAgePencil);
        if (ivEditAgePencil != null) ivEditAgePencil.setOnClickListener(startEditAgeListener);

        // Action button click listener (EDIT PROFILE / SAVE CHANGES)
        btnProfileActionButton.setOnClickListener(v -> {
            SoundManager.getInstance(this).playClick(this);
            onActionButtonClicked();
        });

        btnCredits = findViewById(R.id.btnCredits);
        btnResetData = findViewById(R.id.btnResetData);

        // Load saved sound volumes
        loadSoundSettings();

        // Sound slider change listeners
        SeekBar.OnSeekBarChangeListener soundChangeListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    saveSoundSettings();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                saveSoundSettings();
                if (seekBar == sliderSfx) {
                    SoundManager.getInstance(settingspage.this).playClick(settingspage.this);
                }
            }
        };

        if (sliderMusic != null) sliderMusic.setOnSeekBarChangeListener(soundChangeListener);
        if (sliderSfx != null) sliderSfx.setOnSeekBarChangeListener(soundChangeListener);

        // Credits button
        if (btnCredits != null) {
            btnCredits.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                showCreditsDialog();
            });
        }

        // Reset Data button
        if (btnResetData != null) {
            btnResetData.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                showResetConfirmationDialog();
            });
        }

        // Start in view mode
        setEditingEnabled(false);
    }

    private void loadProfileData() {
        SharedPreferences prefs = getSharedPreferences("UserProfile", MODE_PRIVATE);
        savedName = prefs.getString("userName", "Josh");
        savedGender = prefs.getString("userGender", "Male");
        savedAge = prefs.getInt("userAge", 19);

        currentGender = savedGender;

        etProfileName.setText(savedName);
        etProfileAge.setText(String.valueOf(savedAge));

        updateGenderUI(currentGender);
    }

    private void updateGenderUI(String gender) {
        currentGender = gender;
        if (btnGenderMale != null) btnGenderMale.setSelected("Male".equalsIgnoreCase(gender));
        if (btnGenderFemale != null) btnGenderFemale.setSelected("Female".equalsIgnoreCase(gender));
        if (btnGenderOther != null) btnGenderOther.setSelected("Other".equalsIgnoreCase(gender));
    }

    private void onGenderSelected(String gender) {
        if (!isEditMode) {
            // Enable editing if user taps a gender button
            setEditingEnabled(true);
        }
        updateGenderUI(gender);
        checkIfModified();
    }

    private void setEditingEnabled(boolean enabled) {
        isEditMode = enabled;
        etProfileName.setEnabled(enabled);
        etProfileAge.setEnabled(enabled);
        btnGenderMale.setEnabled(enabled);
        btnGenderFemale.setEnabled(enabled);
        btnGenderOther.setEnabled(enabled);

        if (!enabled) {
            btnProfileActionButton.setImageResource(R.drawable.btn_edit_profile_purple);
        }
    }

    private void checkIfModified() {
        String enteredName = etProfileName.getText().toString().trim();
        String enteredAgeStr = etProfileAge.getText().toString().trim();

        boolean isModified = !enteredName.equals(savedName)
                || !currentGender.equalsIgnoreCase(savedGender)
                || !enteredAgeStr.equals(String.valueOf(savedAge));

        if (isEditMode || isModified) {
            // Show the green SAVE CHANGES button
            btnProfileActionButton.setImageResource(R.drawable.btn_save_changes_green);
        } else {
            btnProfileActionButton.setImageResource(R.drawable.btn_edit_profile_purple);
        }
    }

    private void onActionButtonClicked() {
        if (!isEditMode) {
            // Enter edit mode
            setEditingEnabled(true);
            etProfileName.requestFocus();
            etProfileName.setSelection(etProfileName.getText().length());
            btnProfileActionButton.setImageResource(R.drawable.btn_save_changes_green);
            Toast.makeText(this, "Edit mode enabled", Toast.LENGTH_SHORT).show();
        } else {
            // Save changes
            String newName = etProfileName.getText().toString().trim();
            String ageStr = etProfileAge.getText().toString().trim();

            if (newName.isEmpty()) {
                Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show();
                return;
            }

            int newAge = savedAge;
            try {
                if (!ageStr.isEmpty()) {
                    newAge = Integer.parseInt(ageStr);
                }
            } catch (NumberFormatException e) {
                newAge = savedAge;
            }

            savedName = newName;
            savedGender = currentGender;
            savedAge = Math.max(1, newAge);

            // Persist to SharedPreferences
            getSharedPreferences("UserProfile", MODE_PRIVATE)
                    .edit()
                    .putString("userName", savedName)
                    .putString("userGender", savedGender)
                    .putInt("userAge", savedAge)
                    .apply();

            Toast.makeText(this, "Profile saved!", Toast.LENGTH_SHORT).show();

            // Exit edit mode and show purple EDIT PROFILE button
            setEditingEnabled(false);
        }
    }

    private void loadSoundSettings() {
        SharedPreferences prefs = getSharedPreferences("UserProfile", MODE_PRIVATE);
        int musicVol = prefs.getInt("musicVolume", 75);
        int sfxVol = prefs.getInt("sfxVolume", 75);
        if (sliderMusic != null) sliderMusic.setProgress(musicVol);
        if (sliderSfx != null) sliderSfx.setProgress(sfxVol);
    }

    private void saveSoundSettings() {
        if (sliderMusic == null || sliderSfx == null) return;
        getSharedPreferences("UserProfile", MODE_PRIVATE)
                .edit()
                .putInt("musicVolume", sliderMusic.getProgress())
                .putInt("sfxVolume", sliderSfx.getProgress())
                .apply();
    }

    private void showCreditsDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Credits")
                .setMessage("CODELINGS\n\nDeveloped with passion for learning and coding.\n\nCreated by:\nDaniel Joshua Madrid & Team\n\nVersion 1.0\nThank you for playing!")
                .setPositiveButton("Close", null)
                .show();
    }

    private void showResetConfirmationDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.setContentView(R.layout.delete_confirmation);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        ImageButton btnDialogReturn = dialog.findViewById(R.id.btnDialogReturn);
        ImageButton btnDialogDelete = dialog.findViewById(R.id.btnDialogDelete);

        if (btnDialogReturn != null) {
            btnDialogReturn.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
            });
        }

        if (btnDialogDelete != null) {
            btnDialogDelete.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
                resetAllData();
            });
        }

        dialog.show();
    }

    private void resetAllData() {
        savedName = "Josh";
        savedGender = "Male";
        savedAge = 19;
        currentGender = "Male";

        getSharedPreferences("UserProfile", MODE_PRIVATE)
                .edit()
                .clear()
                .putString("userName", savedName)
                .putString("userGender", savedGender)
                .putInt("userAge", savedAge)
                .putInt("musicVolume", 75)
                .putInt("sfxVolume", 75)
                .putInt("python_unlocked_level", 1)
                .putInt("python_completed_levels", 0)
                .apply();

        etProfileName.setText(savedName);
        etProfileAge.setText(String.valueOf(savedAge));
        updateGenderUI(currentGender);
        if (sliderMusic != null) sliderMusic.setProgress(75);
        if (sliderSfx != null) sliderSfx.setProgress(75);
        setEditingEnabled(false);

        Toast.makeText(this, "Data has been reset to defaults!", Toast.LENGTH_SHORT).show();
    }
}
package com.example.codelings;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Startpage extends AppCompatActivity {

    private EditText etName;
    private ImageButton btnMale, btnFemale, btnOther;
    private SeekBar sbAge;
    private TextView tvAge;
    private Button btnSubmit;

    private String selectedGender = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.startpage);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Reset player level progress each time the app opens fresh
        getSharedPreferences("UserProfile", MODE_PRIVATE)
                .edit()
                .putInt("python_unlocked_level", 1)
                .putInt("python_completed_levels", 0)
                .apply();

        // Initialize UI components
        etName = findViewById(R.id.etName);
        btnMale = findViewById(R.id.btnMale);
        btnFemale = findViewById(R.id.btnFemale);
        btnOther = findViewById(R.id.btnOther);
        sbAge = findViewById(R.id.sbAge);
        tvAge = findViewById(R.id.tvAge);
        btnSubmit = findViewById(R.id.btnSubmit);

        // Name text watcher
        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                checkFormCompletion();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Gender button clicks
        if (btnMale != null) btnMale.setOnClickListener(v -> selectGender("Male", btnMale));
        if (btnFemale != null) btnFemale.setOnClickListener(v -> selectGender("Female", btnFemale));
        if (btnOther != null) btnOther.setOnClickListener(v -> selectGender("Other", btnOther));

        // Age slider listener
        sbAge.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress > 0) {
                    tvAge.setText("Age: " + progress);
                } else {
                    tvAge.setText("Select your age");
                }
                checkFormCompletion();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Initialize age display to not yet chosen
        sbAge.setProgress(0);
        tvAge.setText("Select your age");

        // Initial validation check
        checkFormCompletion();

        // Submit button click
        btnSubmit.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            int age = Math.max(1, sbAge.getProgress());

            getSharedPreferences("UserProfile", MODE_PRIVATE)
                    .edit()
                    .putString("userName", name)
                    .putString("userGender", selectedGender)
                    .putInt("userAge", age)
                    .apply();

            Intent intent = new Intent(Startpage.this, Menupage.class);
            intent.putExtra("userName", name);
            intent.putExtra("userGender", selectedGender);
            intent.putExtra("userAge", age);
            startActivity(intent);
        });
    }

    private void selectGender(String gender, ImageButton selectedBtn) {
        selectedGender = gender;
        if (btnMale != null) btnMale.setSelected(btnMale == selectedBtn);
        if (btnFemale != null) btnFemale.setSelected(btnFemale == selectedBtn);
        if (btnOther != null) btnOther.setSelected(btnOther == selectedBtn);
        checkFormCompletion();
    }

    private void checkFormCompletion() {
        if (etName == null || btnSubmit == null || sbAge == null) return;

        boolean hasName = etName.getText() != null && !etName.getText().toString().trim().isEmpty();
        boolean hasGender = selectedGender != null;
        boolean hasAge = sbAge.getProgress() > 0;

        boolean isComplete = hasName && hasGender && hasAge;

        btnSubmit.setEnabled(isComplete);
        btnSubmit.setBackgroundResource(isComplete ? R.drawable.btn_submit_active : R.drawable.btn_submit_inactive);
    }
}

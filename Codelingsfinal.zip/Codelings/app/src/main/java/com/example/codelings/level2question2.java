package com.example.codelings;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class level2question2 extends AppCompatActivity {

    private ImageButton btnBack;
    private ImageButton btnNext;
    private ImageView ivHearts;
    private ImageView ivProgress;
    private RelativeLayout btnOption1, btnOption2, btnOption3, btnOption4;
    private ImageView ivOption1Bg, ivOption2Bg, ivOption3Bg, ivOption4Bg;

    private int selectedOptionIndex = -1;
    private final int correctAnswerIndex = 1; // Option B -> "It ignores the comment"[cite: 1]

    private int heartsCount = 3;
    private final int[] heartsDrawables = new int[] {
            R.drawable.hearts_0,
            R.drawable.hearts_1,
            R.drawable.hearts_2,
            R.drawable.hearts_3
    };

    private final int[] pillDrawables = new int[] {
            R.drawable.pill_progress_0_10,
            R.drawable.pill_progress_1_10,
            R.drawable.pill_progress_2_10,
            R.drawable.pill_progress_3_10,
            R.drawable.pill_progress_4_10,
            R.drawable.pill_progress_5_10,
            R.drawable.pill_progress_6_10,
            R.drawable.pill_progress_7_10,
            R.drawable.pill_progress_8_10,
            R.drawable.pill_progress_9_10,
            R.drawable.pill_progress_10_10
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.level2question2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnBack = findViewById(R.id.btnLevel2Q2Back);
        btnNext = findViewById(R.id.btnNext);
        ivHearts = findViewById(R.id.ivHearts);
        ivProgress = findViewById(R.id.ivProgress);

        if (ivProgress != null) {
            ivProgress.setImageResource(R.drawable.progress_bar_2);
        }

        btnOption1 = findViewById(R.id.btnOption1);
        btnOption2 = findViewById(R.id.btnOption2);
        btnOption3 = findViewById(R.id.btnOption3);
        btnOption4 = findViewById(R.id.btnOption4);

        ivOption1Bg = findViewById(R.id.ivOption1Bg);
        ivOption2Bg = findViewById(R.id.ivOption2Bg);
        ivOption3Bg = findViewById(R.id.ivOption3Bg);
        ivOption4Bg = findViewById(R.id.ivOption4Bg);

        heartsCount = getIntent().getIntExtra("HEARTS_COUNT", level1.currentHearts);
        level1.currentHearts = heartsCount;
        updateHeartsDisplay();

        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                finish();
            });
        }

        setupOptionClick(btnOption1, 0);
        setupOptionClick(btnOption2, 1);
        setupOptionClick(btnOption3, 2);
        setupOptionClick(btnOption4, 3);

        if (btnNext != null) {
            btnNext.setImageResource(R.drawable.btn_next_inactive);
            btnNext.setOnClickListener(v -> {
                if (selectedOptionIndex == -1) {
                    SoundManager.getInstance(this).playClick(this);
                    Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (selectedOptionIndex == correctAnswerIndex) {
                    SoundManager.getInstance(this).playCorrect(this);

                    // Unlock Level 3 and update completed levels
                    SharedPreferences prefs = getSharedPreferences("UserProfile", MODE_PRIVATE);
                    int currentCompleted = prefs.getInt("python_completed_levels", 1);
                    int currentUnlocked = prefs.getInt("python_unlocked_level", 2);
                    prefs.edit()
                            .putInt("python_unlocked_level", Math.max(currentUnlocked, 3))
                            .putInt("python_completed_levels", Math.max(currentCompleted, 2))
                            .apply();

                    showLevelCompleteDialog();
                } else {
                    SoundManager.getInstance(this).playIncorrect(this);
                    if (level1.currentHearts > 1) {
                        level1.currentHearts--;
                        heartsCount = level1.currentHearts;
                        updateHeartsDisplay();
                        Toast.makeText(this, "Incorrect! Try again.", Toast.LENGTH_SHORT).show();
                    } else {
                        level1.currentHearts = 0;
                        heartsCount = 0;
                        updateHeartsDisplay();
                        showLevelLoseDialog();
                    }
                }
            });
        }
    }

    private void updateHeartsDisplay() {
        if (ivHearts != null && heartsCount >= 0 && heartsCount < heartsDrawables.length) {
            ivHearts.setImageResource(heartsDrawables[heartsCount]);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        heartsCount = level1.currentHearts;
        updateHeartsDisplay();
    }

    private void setupOptionClick(RelativeLayout optionBtn, int index) {
        if (optionBtn != null) {
            optionBtn.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                selectedOptionIndex = index;
                if (ivOption1Bg != null) ivOption1Bg.setImageResource(index == 0 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                if (ivOption2Bg != null) ivOption2Bg.setImageResource(index == 1 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                if (ivOption3Bg != null) ivOption3Bg.setImageResource(index == 2 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                if (ivOption4Bg != null) ivOption4Bg.setImageResource(index == 3 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);

                if (btnNext != null) {
                    btnNext.setImageResource(R.drawable.btn_next);
                }
            });
        }
    }

    private void showLevelCompleteDialog() {
        SoundManager.getInstance(this).playVictory(this);
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.setContentView(R.layout.dialog_level_complete);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        ImageButton btnNextLevel = dialog.findViewById(R.id.btnCongratsNextLevel);
        ImageButton btnPlayAgain = dialog.findViewById(R.id.btnCongratsPlayAgain);
        ImageButton btnReturnHome = dialog.findViewById(R.id.btnCongratsReturnHome);
        ImageView ivDialogProgress = dialog.findViewById(R.id.ivDialogProgress);

        if (ivDialogProgress != null) {
            SharedPreferences prefs = getSharedPreferences("UserProfile", MODE_PRIVATE);
            int completedLevels = prefs.getInt("python_completed_levels", 2);
            if (completedLevels < 0) completedLevels = 0;
            if (completedLevels > 10) completedLevels = 10;
            ivDialogProgress.setImageResource(pillDrawables[completedLevels]);
            ivDialogProgress.setContentDescription(completedLevels + "/10 Levels Complete");
        }

        // NEXT LEVEL: Go straight to Level 3
        if (btnNextLevel != null) {
            btnNextLevel.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
                level1.currentHearts = 3;
                Intent intent = new Intent(level2question2.this, level3.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        if (btnPlayAgain != null) {
            btnPlayAgain.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
                level1.currentHearts = 3;
                Intent intent = new Intent(level2question2.this, level2.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        if (btnReturnHome != null) {
            btnReturnHome.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
                level1.currentHearts = 3;
                Intent intent = new Intent(level2question2.this, pythonlanguage.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        dialog.show();
    }

    private void showLevelLoseDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.setContentView(R.layout.dialog_level_lose);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        ImageButton btnLosePlayAgain = dialog.findViewById(R.id.btnLosePlayAgain);
        ImageButton btnLoseReturnHome = dialog.findViewById(R.id.btnLoseReturnHome);

        if (btnLosePlayAgain != null) {
            btnLosePlayAgain.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
                level1.currentHearts = 3;
                Intent intent = new Intent(level2question2.this, level2.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        if (btnLoseReturnHome != null) {
            btnLoseReturnHome.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
                level1.currentHearts = 3;
                Intent intent = new Intent(level2question2.this, pythonlanguage.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        dialog.show();
    }
}
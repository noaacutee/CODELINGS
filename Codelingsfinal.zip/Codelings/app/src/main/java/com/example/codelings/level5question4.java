package com.example.codelings;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class level5question4 extends AppCompatActivity {
    private int selectedOptionIndex = -1;
    private final int correctAnswerIndex = 1; // Option B ("20")
    private int heartsCount = 3;
    private final int[] heartsDrawables = {
            R.drawable.hearts_0,
            R.drawable.hearts_1,
            R.drawable.hearts_2,
            R.drawable.hearts_3
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.level5question4);

        // Get hearts count safely from intent or global state
        heartsCount = getIntent().getIntExtra("HEARTS_COUNT", level1.currentHearts);
        level1.currentHearts = heartsCount;

        ImageView ivHearts = findViewById(R.id.ivHearts);
        ImageView ivProgress = findViewById(R.id.ivProgress);

        // Ensure index is within safe bounds [0, 3] before setting drawable
        if (ivHearts != null) {
            int safeIndex = Math.max(0, Math.min(heartsCount, heartsDrawables.length - 1));
            ivHearts.setImageResource(heartsDrawables[safeIndex]);
        }

        // If your progress bar file name is different (e.g. progress_bar4), update it here
        if (ivProgress != null) {
            ivProgress.setImageResource(R.drawable.pill_progress_4_10);
        }

        // Setup option click listeners
        setupOptionClick(findViewById(R.id.btnOption1), 0);
        setupOptionClick(findViewById(R.id.btnOption2), 1);
        setupOptionClick(findViewById(R.id.btnOption3), 2);
        setupOptionClick(findViewById(R.id.btnOption4), 3);

        // Setup Next Button click listener
        ImageButton btnNext = findViewById(R.id.btnNext);
        if (btnNext != null) {
            btnNext.setImageResource(R.drawable.btn_next_inactive);
            btnNext.setOnClickListener(v -> {
                if (selectedOptionIndex == -1) {
                    Toast.makeText(this, "Select an answer", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (selectedOptionIndex == correctAnswerIndex) {
                    // Correct Answer
                    SoundManager.getInstance(this).playCorrect(this);
                    Intent intent = new Intent(this, level5question5.class);
                    intent.putExtra("HEARTS_COUNT", level1.currentHearts);
                    startActivity(intent);
                    finish();
                } else {
                    // Incorrect Answer
                    SoundManager.getInstance(this).playIncorrect(this);

                    level1.currentHearts--;
                    heartsCount = level1.currentHearts; // Sync local state

                    // Update hearts UI safely
                    if (ivHearts != null) {
                        int safeIndex = Math.max(0, Math.min(level1.currentHearts, heartsDrawables.length - 1));
                        ivHearts.setImageResource(heartsDrawables[safeIndex]);
                    }

                    // Check if player ran out of hearts -> Show custom lose dialog
                    if (level1.currentHearts <= 0) {
                        showLoseDialog();
                    } else {
                        Toast.makeText(this, "Incorrect!", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void setupOptionClick(RelativeLayout btn, int index) {
        if (btn != null) {
            btn.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                selectedOptionIndex = index;

                // Update option backgrounds
                ((ImageView)findViewById(R.id.ivOption1Bg)).setImageResource(index == 0 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                ((ImageView)findViewById(R.id.ivOption2Bg)).setImageResource(index == 1 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                ((ImageView)findViewById(R.id.ivOption3Bg)).setImageResource(index == 2 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                ((ImageView)findViewById(R.id.ivOption4Bg)).setImageResource(index == 3 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);

                // Activate next button
                ImageButton btnNext = findViewById(R.id.btnNext);
                if (btnNext != null) {
                    btnNext.setImageResource(R.drawable.btn_next);
                }
            });
        }
    }

    private void showLoseDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_level_lose, null);
        builder.setView(dialogView);
        builder.setCancelable(false);

        AlertDialog loseDialog = builder.create();
        if (loseDialog.getWindow() != null) {
            loseDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        // Play Again Button
        ImageButton btnPlayAgain = dialogView.findViewById(R.id.btnLosePlayAgain);
        if (btnPlayAgain != null) {
            btnPlayAgain.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                level1.currentHearts = 3; // Reset hearts
                Intent intent = new Intent(this, level5question1.class); // Or restart current level
                startActivity(intent);
                finish();
            });
        }

        // Return Home Button
        ImageButton btnReturnHome = dialogView.findViewById(R.id.btnLoseReturnHome);
        if (btnReturnHome != null) {
            btnReturnHome.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                Intent intent = new Intent(this, Menupage.class); // Change to your main menu activity if different
                startActivity(intent);
                finish();
            });
        }

        // Quit Button
        ImageButton btnQuit = dialogView.findViewById(R.id.btnLoseQuit);
        if (btnQuit != null) {
            btnQuit.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                finishAffinity(); // Exits app
            });
        }

        loseDialog.show();
    }
}
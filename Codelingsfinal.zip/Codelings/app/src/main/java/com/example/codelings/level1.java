package com.example.codelings;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class level1 extends AppCompatActivity {

    private ImageView ivHearts;
    private ImageView ivProgress;
    private ImageButton btnNext;
    private ImageButton btnBack;

    private int progressStep = 0;
    private final int[] progressDrawables = new int[] {
        R.drawable.progress_bar_0, // Starts with no green
        R.drawable.progress_bar_1, // 1/3 green
        R.drawable.progress_bar_2, // 2/3 green
        R.drawable.progress_bar_3  // Full green
    };

    public static int currentHearts = 3;

    private int heartsCount = 3;
    private final int[] heartsDrawables = new int[] {
        R.drawable.hearts_0,
        R.drawable.hearts_1,
        R.drawable.hearts_2,
        R.drawable.hearts_3
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.level1);

        currentHearts = 3; // Reset to 3 when entering level 1 fresh

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ivHearts = findViewById(R.id.ivHearts);
        ivProgress = findViewById(R.id.ivProgress);
        btnNext = findViewById(R.id.btnNext);
        btnBack = findViewById(R.id.btnLevel1Back);

        if (ivHearts != null) {
            ivHearts.setImageResource(heartsDrawables[currentHearts]);
        }

        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                showLeaveConfirmationDialog();
            });
        }

        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                showLeaveConfirmationDialog();
            }
        });

        // Progress initially starts with bar_0
        if (ivProgress != null) {
            ivProgress.setImageResource(R.drawable.progress_bar_0);
        }

        if (btnNext != null) {
            btnNext.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                Intent intent = new Intent(level1.this, level1question1.class);
                intent.putExtra("HEARTS_COUNT", currentHearts);
                startActivity(intent);
            });
        }
    }

    private void showLeaveConfirmationDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.setContentView(R.layout.dialog_leave_level);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        ImageButton btnDialogStay = dialog.findViewById(R.id.btnDialogStay);
        ImageButton btnDialogQuit = dialog.findViewById(R.id.btnDialogQuit);

        if (btnDialogStay != null) {
            btnDialogStay.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
            });
        }

        if (btnDialogQuit != null) {
            btnDialogQuit.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
                currentHearts = 3;
                Intent intent = new Intent(level1.this, pythonlanguage.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        dialog.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ivHearts != null) {
            ivHearts.setImageResource(heartsDrawables[currentHearts]);
        }
    }
}
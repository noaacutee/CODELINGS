package com.example.codelings;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.SoundPool;

public class SoundManager {

    private static SoundManager instance;
    private SoundPool soundPool;
    private int soundClick = 0;
    private int soundCorrect = 0;
    private int soundIncorrect = 0;
    private int soundVictory = 0;
    private boolean loaded = false;

    private SoundManager(Context context) {
        Context appContext = context.getApplicationContext();
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        soundPool = new SoundPool.Builder()
                .setMaxStreams(5)
                .setAudioAttributes(audioAttributes)
                .build();

        soundPool.setOnLoadCompleteListener((pool, sampleId, status) -> {
            if (status == 0) {
                loaded = true;
            }
        });

        soundClick = soundPool.load(appContext, R.raw.sfx_click, 1);
        soundCorrect = soundPool.load(appContext, R.raw.sfx_correct, 1);
        soundIncorrect = soundPool.load(appContext, R.raw.sfx_incorrect, 1);
        soundVictory = soundPool.load(appContext, R.raw.sfx_victory, 1);
    }

    public static synchronized SoundManager getInstance(Context context) {
        if (instance == null) {
            instance = new SoundManager(context);
        }
        return instance;
    }

    private float getSfxVolume(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("UserProfile", Context.MODE_PRIVATE);
        int volPercent = prefs.getInt("sfxVolume", 75);
        return Math.max(0.0f, Math.min(1.0f, volPercent / 100.0f));
    }

    public void playClick(Context context) {
        playSound(context, soundClick);
    }

    public void playCorrect(Context context) {
        playSound(context, soundCorrect);
    }

    public void playIncorrect(Context context) {
        playSound(context, soundIncorrect);
    }

    public void playVictory(Context context) {
        playSound(context, soundVictory);
    }

    private void playSound(Context context, int soundId) {
        if (soundPool != null && soundId != 0) {
            float volume = getSfxVolume(context);
            if (volume > 0.0f) {
                soundPool.play(soundId, volume, volume, 1, 0, 1.0f);
            }
        }
    }
}

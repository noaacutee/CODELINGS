package com.example.codelings;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class level1question1 extends AppCompatActivity {

    private ImageButton btnBack;
    private ImageButton btnNext;
    private TextView tvQuestion;
    private ImageView ivHearts;
    private ImageView ivProgress;
    private RelativeLayout btnOption1, btnOption2, btnOption3, btnOption4;
    private ImageView ivOption1Bg, ivOption2Bg, ivOption3Bg, ivOption4Bg;
    private TextView tvOption1, tvOption2, tvOption3, tvOption4;

    private int selectedOptionIndex = -1;
    private final int correctAnswerIndex = 0; // Answer: A -> print("Hello, World!")

    private int heartsCount = 3;
    private final int[] heartsDrawables = new int[] {
        R.drawable.hearts_0,
        R.drawable.hearts_1,
        R.drawable.hearts_2,
        R.drawable.hearts_3
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.level1question1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnBack = findViewById(R.id.btnBack);
        btnNext = findViewById(R.id.btnNext);
        tvQuestion = findViewById(R.id.tvQuestion);
        ivHearts = findViewById(R.id.ivHearts);
        ivProgress = findViewById(R.id.ivProgress);

        if (ivProgress != null) {
            ivProgress.setImageResource(R.drawable.progress_bar_1);
        }

        btnOption1 = findViewById(R.id.btnOption1);
        btnOption2 = findViewById(R.id.btnOption2);
        btnOption3 = findViewById(R.id.btnOption3);
        btnOption4 = findViewById(R.id.btnOption4);

        ivOption1Bg = findViewById(R.id.ivOption1Bg);
        ivOption2Bg = findViewById(R.id.ivOption2Bg);
        ivOption3Bg = findViewById(R.id.ivOption3Bg);
        ivOption4Bg = findViewById(R.id.ivOption4Bg);

        tvOption1 = findViewById(R.id.tvOption1);
        tvOption2 = findViewById(R.id.tvOption2);
        tvOption3 = findViewById(R.id.tvOption3);
        tvOption4 = findViewById(R.id.tvOption4);

        heartsCount = getIntent().getIntExtra("HEARTS_COUNT", level1.currentHearts);
        level1.currentHearts = heartsCount;
        updateHeartsDisplay();

        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                showLeaveConfirmationDialog();
            });
        }

        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                showLeaveConfirmationDialog();
            }
        });

        // Selection listeners for the 4 options
        setupOptionClick(btnOption1, 0);
        setupOptionClick(btnOption2, 1);
        setupOptionClick(btnOption3, 2);
        setupOptionClick(btnOption4, 3);

        if (btnNext != null) {
            btnNext.setImageResource(R.drawable.btn_next_inactive);
            btnNext.setOnClickListener(v -> {
                if (selectedOptionIndex == -1) {
                    Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (selectedOptionIndex == correctAnswerIndex) {
                    SoundManager.getInstance(this).playCorrect(this);
                    Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(level1question1.this, level1question2.class);
                    intent.putExtra("HEARTS_COUNT", level1.currentHearts);
                    startActivity(intent);
                } else {
                    SoundManager.getInstance(this).playIncorrect(this);
                    if (level1.currentHearts > 1) {
                        level1.currentHearts--;
                        heartsCount = level1.currentHearts;
                        updateHeartsDisplay();
                        Toast.makeText(this, "Incorrect! Try again.", Toast.LENGTH_SHORT).show();
                    } else {
                        level1.currentHearts = 0;
                        heartsCount = 0;
                        updateHeartsDisplay();
                        showLevelLoseDialog();
                    }
                }
            });
        }
    }

    private void updateHeartsDisplay() {
        if (ivHearts != null && heartsCount >= 0 && heartsCount < heartsDrawables.length) {
            ivHearts.setImageResource(heartsDrawables[heartsCount]);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        heartsCount = level1.currentHearts;
        updateHeartsDisplay();
    }

    private void setupOptionClick(RelativeLayout optionBtn, int index) {
        if (optionBtn != null) {
            optionBtn.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                selectedOptionIndex = index;
                // Highlight chosen answer, set not chosen answers to bg_option_not_chosen
                if (ivOption1Bg != null) ivOption1Bg.setImageResource(index == 0 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                if (ivOption2Bg != null) ivOption2Bg.setImageResource(index == 1 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                if (ivOption3Bg != null) ivOption3Bg.setImageResource(index == 2 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                if (ivOption4Bg != null) ivOption4Bg.setImageResource(index == 3 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);

                // Change NEXT button to green when user chooses an answer
                if (btnNext != null) {
                    btnNext.setImageResource(R.drawable.btn_next);
                }
            });
        }
    }

    private void showLeaveConfirmationDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.setContentView(R.layout.dialog_leave_level);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        ImageButton btnDialogStay = dialog.findViewById(R.id.btnDialogStay);
        ImageButton btnDialogQuit = dialog.findViewById(R.id.btnDialogQuit);

        if (btnDialogStay != null) {
            btnDialogStay.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
            });
        }

        if (btnDialogQuit != null) {
            btnDialogQuit.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
                level1.currentHearts = 3;
                Intent intent = new Intent(level1question1.this, pythonlanguage.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        dialog.show();
    }

    private void showLevelLoseDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.setContentView(R.layout.dialog_level_lose);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        ImageButton btnLosePlayAgain = dialog.findViewById(R.id.btnLosePlayAgain);
        ImageButton btnLoseReturnHome = dialog.findViewById(R.id.btnLoseReturnHome);
        ImageButton btnLoseQuit = dialog.findViewById(R.id.btnLoseQuit);

        if (btnLosePlayAgain != null) {
            btnLosePlayAgain.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
                level1.currentHearts = 3;
                Intent intent = new Intent(level1question1.this, level1.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        if (btnLoseReturnHome != null) {
            btnLoseReturnHome.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
                level1.currentHearts = 3;
                Intent intent = new Intent(level1question1.this, pythonlanguage.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        if (btnLoseQuit != null) {
            btnLoseQuit.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                dialog.dismiss();
                level1.currentHearts = 3;
                Intent intent = new Intent(level1question1.this, Menupage.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                finish();
            });
        }

        dialog.show();
    }
}
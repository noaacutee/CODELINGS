package com.example.codelings;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class level5question5 extends AppCompatActivity {
    private int selectedOptionIndex = -1;
    private final int correctAnswerIndex = 0; // Option A ("10")
    private int heartsCount = 3;
    private final int[] heartsDrawables = {R.drawable.hearts_0, R.drawable.hearts_1, R.drawable.hearts_2, R.drawable.hearts_3};
    private final int[] pillDrawables = {
            R.drawable.pill_progress_0_10, R.drawable.pill_progress_1_10, R.drawable.pill_progress_2_10,
            R.drawable.pill_progress_3_10, R.drawable.pill_progress_4_10, R.drawable.pill_progress_5_10,
            R.drawable.pill_progress_6_10, R.drawable.pill_progress_7_10, R.drawable.pill_progress_8_10,
            R.drawable.pill_progress_9_10, R.drawable.pill_progress_10_10
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.level5question5);

        heartsCount = getIntent().getIntExtra("HEARTS_COUNT", level1.currentHearts);
        level1.currentHearts = heartsCount;

        ImageView ivHearts = findViewById(R.id.ivHearts);
        ImageView ivProgress = findViewById(R.id.ivProgress);
        if (ivHearts != null) ivHearts.setImageResource(heartsDrawables[heartsCount]);
        if (ivProgress != null) ivProgress.setImageResource(R.drawable.pill_progress_5_10);

        setupOptionClick(findViewById(R.id.btnOption1), 0);
        setupOptionClick(findViewById(R.id.btnOption2), 1);
        setupOptionClick(findViewById(R.id.btnOption3), 2);
        setupOptionClick(findViewById(R.id.btnOption4), 3);

        ImageButton btnNext = findViewById(R.id.btnNext);
        if (btnNext != null) {
            btnNext.setImageResource(R.drawable.btn_next_inactive);
            btnNext.setOnClickListener(v -> {
                if (selectedOptionIndex == -1) { Toast.makeText(this, "Select an answer", Toast.LENGTH_SHORT).show(); return; }
                if (selectedOptionIndex == correctAnswerIndex) {
                    SoundManager.getInstance(this).playCorrect(this);

                    SharedPreferences prefs = getSharedPreferences("UserProfile", MODE_PRIVATE);
                    int currentCompleted = prefs.getInt("python_completed_levels", 4);
                    int currentUnlocked = prefs.getInt("python_unlocked_level", 5);
                    prefs.edit()
                            .putInt("python_unlocked_level", Math.max(currentUnlocked, 6))
                            .putInt("python_completed_levels", Math.max(currentCompleted, 5))
                            .apply();

                    showLevelCompleteDialog();
                } else {
                    SoundManager.getInstance(this).playIncorrect(this);
                    level1.currentHearts--;
                    if (ivHearts != null) ivHearts.setImageResource(heartsDrawables[Math.max(0, level1.currentHearts)]);
                }
            });
        }
    }

    private void setupOptionClick(RelativeLayout btn, int index) {
        if (btn != null) {
            btn.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                selectedOptionIndex = index;
                ((ImageView)findViewById(R.id.ivOption1Bg)).setImageResource(index == 0 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                ((ImageView)findViewById(R.id.ivOption2Bg)).setImageResource(index == 1 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                ((ImageView)findViewById(R.id.ivOption3Bg)).setImageResource(index == 2 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                ((ImageView)findViewById(R.id.ivOption4Bg)).setImageResource(index == 3 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                ImageButton btnNext = findViewById(R.id.btnNext);
                if (btnNext != null) btnNext.setImageResource(R.drawable.btn_next);
            });
        }
    }

    private void showLevelCompleteDialog() {
        SoundManager.getInstance(this).playVictory(this);
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.setContentView(R.layout.dialog_level_complete);
        dialog.setCancelable(false);
        if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        ImageButton btnNextLevel = dialog.findViewById(R.id.btnCongratsNextLevel);
        ImageButton btnPlayAgain = dialog.findViewById(R.id.btnCongratsPlayAgain);
        ImageButton btnReturnHome = dialog.findViewById(R.id.btnCongratsReturnHome);
        ImageView ivDialogProgress = dialog.findViewById(R.id.ivDialogProgress);

        if (ivDialogProgress != null) {
            SharedPreferences prefs = getSharedPreferences("UserProfile", MODE_PRIVATE);
            int completed = prefs.getInt("python_completed_levels", 5);
            ivDialogProgress.setImageResource(pillDrawables[Math.min(completed, 10)]);
        }

        if (btnNextLevel != null) btnNextLevel.setOnClickListener(v -> { level1.currentHearts = 3; startActivity(new Intent(this, level6.class)); finish(); });
        if (btnPlayAgain != null) btnPlayAgain.setOnClickListener(v -> { level1.currentHearts = 3; startActivity(new Intent(this, level5.class)); finish(); });
        if (btnReturnHome != null) btnReturnHome.setOnClickListener(v -> { level1.currentHearts = 3; startActivity(new Intent(this, pythonlanguage.class)); finish(); });
        dialog.show();
    }
}
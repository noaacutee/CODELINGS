package com.example.codelings;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class chooseyourlanguage extends AppCompatActivity {

    private ImageView ivPythonProgress;
    private final int[] pillDrawables = new int[] {
        R.drawable.pill_progress_0_10,
        R.drawable.pill_progress_1_10,
        R.drawable.pill_progress_2_10,
        R.drawable.pill_progress_3_10,
        R.drawable.pill_progress_4_10,
        R.drawable.pill_progress_5_10,
        R.drawable.pill_progress_6_10,
        R.drawable.pill_progress_7_10,
        R.drawable.pill_progress_8_10,
        R.drawable.pill_progress_9_10,
        R.drawable.pill_progress_10_10
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.chooseyourlanguage);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageButton btnBack = findViewById(R.id.btnChooseLanguageBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                finish();
            });
        }

        ImageButton btnPython = findViewById(R.id.btnLanguagePython);
        if (btnPython != null) {
            btnPython.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                Intent intent = new Intent(this, pythonlanguage.class);
                startActivity(intent);
            });
        }

        ImageButton btnCpp = findViewById(R.id.btnLanguageCpp);
        if (btnCpp != null) {
            btnCpp.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                Toast.makeText(this, "Finish Python to unlock C++!", Toast.LENGTH_SHORT).show();
            });
        }

        ImageButton btnLocked = findViewById(R.id.btnLanguageLocked);
        if (btnLocked != null) {
            btnLocked.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                Toast.makeText(this, "Coming Soon!", Toast.LENGTH_SHORT).show();
            });
        }

        ivPythonProgress = findViewById(R.id.ivPythonProgress);
        updateProgress();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateProgress();
    }

    private void updateProgress() {
        if (ivPythonProgress == null) return;
        SharedPreferences prefs = getSharedPreferences("UserProfile", MODE_PRIVATE);
        int unlockedLevel = prefs.getInt("python_unlocked_level", 1);
        int completedLevels = prefs.getInt("python_completed_levels", Math.max(0, unlockedLevel - 1));
        if (completedLevels < 0) completedLevels = 0;
        if (completedLevels > 10) completedLevels = 10;

        ivPythonProgress.setImageResource(pillDrawables[completedLevels]);
        ivPythonProgress.setContentDescription(completedLevels + "/10 Levels Complete");
    }
}
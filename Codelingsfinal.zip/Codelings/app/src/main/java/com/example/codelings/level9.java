package com.example.codelings;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class level9 extends AppCompatActivity {

    private ImageButton btnBack, btnNext;
    private ImageView ivHearts, ivProgress;
    private int heartsCount = 3;
    private final int[] heartsDrawables = new int[] { R.drawable.hearts_0, R.drawable.hearts_1, R.drawable.hearts_2, R.drawable.hearts_3 };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.level9); // Matches your level9.xml layout file
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        btnBack = findViewById(R.id.btnLevel9Back);
        btnNext = findViewById(R.id.btnNext);
        ivHearts = findViewById(R.id.ivHearts);
        ivProgress = findViewById(R.id.ivProgress);

        // Set progress bar for the lesson page if present
        if (ivProgress != null) {
            ivProgress.setImageResource(R.drawable.progress_bar_0);
        }

        // Retrieve current hearts count passed from previous activities
        heartsCount = getIntent().getIntExtra("HEARTS_COUNT", level1.currentHearts);
        level1.currentHearts = heartsCount;
        updateHeartsDisplay();

        // Back button listener
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                finish();
            });
        }

        // Next button listener to start Level 9 Question 1
        if (btnNext != null) {
            btnNext.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                Intent intent = new Intent(level9.this, level9question1.class);
                intent.putExtra("HEARTS_COUNT", level1.currentHearts);
                startActivity(intent);
            });
        }
    }

    private void updateHeartsDisplay() {
        if (ivHearts != null && heartsCount >= 0 && heartsCount < heartsDrawables.length) {
            ivHearts.setImageResource(heartsDrawables[heartsCount]);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        heartsCount = level1.currentHearts;
        updateHeartsDisplay();
    }
}
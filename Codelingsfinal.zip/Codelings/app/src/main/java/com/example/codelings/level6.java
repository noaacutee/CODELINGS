package com.example.codelings;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class level6 extends AppCompatActivity {

    private ImageView ivHearts;
    private ImageView ivProgress;
    private ImageButton btnNext;
    private ImageButton btnBack;

    private final int[] heartsDrawables = new int[] {
            R.drawable.hearts_0, R.drawable.hearts_1, R.drawable.hearts_2, R.drawable.hearts_3
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.level6);

        if (getIntent().hasExtra("HEARTS_COUNT")) {
            level1.currentHearts = getIntent().getIntExtra("HEARTS_COUNT", 3);
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ivHearts = findViewById(R.id.ivHearts);
        ivProgress = findViewById(R.id.ivProgress);
        btnNext = findViewById(R.id.btnNext);
        btnBack = findViewById(R.id.btnLevel6Back);

        if (ivHearts != null) {
            ivHearts.setImageResource(heartsDrawables[level1.currentHearts]);
        }

        if (ivProgress != null) {
            ivProgress.setImageResource(R.drawable.progress_bar_0);
        }

        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                finish();
            });
        }

        if (btnNext != null) {
            btnNext.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                Intent intent = new Intent(level6.this, level6question1.class);
                intent.putExtra("HEARTS_COUNT", level1.currentHearts);
                startActivity(intent);
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (ivHearts != null) {
            ivHearts.setImageResource(heartsDrawables[level1.currentHearts]);
        }
    }
}
package com.example.codelings;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class level5question1 extends AppCompatActivity {
    private int selectedOptionIndex = -1;
    private final int correctAnswerIndex = 0; // Option A ("#")
    private int heartsCount = 3;
    private final int[] heartsDrawables = {R.drawable.hearts_0, R.drawable.hearts_1, R.drawable.hearts_2, R.drawable.hearts_3};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.level5question1);

        heartsCount = getIntent().getIntExtra("HEARTS_COUNT", level1.currentHearts);
        level1.currentHearts = heartsCount;

        ImageView ivHearts = findViewById(R.id.ivHearts);
        ImageView ivProgress = findViewById(R.id.ivProgress);
        if (ivHearts != null) ivHearts.setImageResource(heartsDrawables[heartsCount]);
        if (ivProgress != null) ivProgress.setImageResource(R.drawable.progress_bar_1);

        setupOptionClick(findViewById(R.id.btnOption1), 0);
        setupOptionClick(findViewById(R.id.btnOption2), 1);
        setupOptionClick(findViewById(R.id.btnOption3), 2);
        setupOptionClick(findViewById(R.id.btnOption4), 3);

        ImageButton btnNext = findViewById(R.id.btnNext);
        if (btnNext != null) {
            btnNext.setImageResource(R.drawable.btn_next_inactive);
            btnNext.setOnClickListener(v -> {
                if (selectedOptionIndex == -1) { Toast.makeText(this, "Select an answer", Toast.LENGTH_SHORT).show(); return; }
                if (selectedOptionIndex == correctAnswerIndex) {
                    SoundManager.getInstance(this).playCorrect(this);
                    Intent intent = new Intent(this, level5question2.class);
                    intent.putExtra("HEARTS_COUNT", level1.currentHearts);
                    startActivity(intent); finish();
                } else {
                    handleIncorrect(ivHearts);
                }
            });
        }
    }

    private void setupOptionClick(RelativeLayout btn, int index) {
        if (btn != null) {
            btn.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                selectedOptionIndex = index;
                ((ImageView)findViewById(R.id.ivOption1Bg)).setImageResource(index == 0 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                ((ImageView)findViewById(R.id.ivOption2Bg)).setImageResource(index == 1 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                ((ImageView)findViewById(R.id.ivOption3Bg)).setImageResource(index == 2 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                ((ImageView)findViewById(R.id.ivOption4Bg)).setImageResource(index == 3 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                ImageButton btnNext = findViewById(R.id.btnNext);
                if (btnNext != null) btnNext.setImageResource(R.drawable.btn_next);
            });
        }
    }

    private void handleIncorrect(ImageView ivHearts) {
        SoundManager.getInstance(this).playIncorrect(this);
        if (level1.currentHearts > 1) {
            level1.currentHearts--;
            if (ivHearts != null) ivHearts.setImageResource(heartsDrawables[level1.currentHearts]);
            Toast.makeText(this, "Incorrect! Try again.", Toast.LENGTH_SHORT).show();
        } else {
            level1.currentHearts = 0;
            if (ivHearts != null) ivHearts.setImageResource(R.drawable.hearts_0);
            // Lose dialog logic
        }
    }
}
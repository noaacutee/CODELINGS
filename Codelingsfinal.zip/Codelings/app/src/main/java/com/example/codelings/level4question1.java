package com.example.codelings;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class level4question1 extends AppCompatActivity {

    private ImageButton btnBack, btnNext;
    private ImageView ivHearts, ivProgress;
    private RelativeLayout btnOption1, btnOption2, btnOption3, btnOption4;
    private ImageView ivOption1Bg, ivOption2Bg, ivOption3Bg, ivOption4Bg;

    private int selectedOptionIndex = -1;
    private final int correctAnswerIndex = 2; // Option C ("str")[cite: 6]
    private int heartsCount = 3;
    private final int[] heartsDrawables = new int[] { R.drawable.hearts_0, R.drawable.hearts_1, R.drawable.hearts_2, R.drawable.hearts_3 };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.level4question1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        btnBack = findViewById(R.id.btnLevel4Q1Back);
        btnNext = findViewById(R.id.btnNext);
        ivHearts = findViewById(R.id.ivHearts);
        ivProgress = findViewById(R.id.ivProgress);

        if (ivProgress != null) ivProgress.setImageResource(R.drawable.progress_bar_1);

        btnOption1 = findViewById(R.id.btnOption1);
        btnOption2 = findViewById(R.id.btnOption2);
        btnOption3 = findViewById(R.id.btnOption3);
        btnOption4 = findViewById(R.id.btnOption4);

        ivOption1Bg = findViewById(R.id.ivOption1Bg);
        ivOption2Bg = findViewById(R.id.ivOption2Bg);
        ivOption3Bg = findViewById(R.id.ivOption3Bg);
        ivOption4Bg = findViewById(R.id.ivOption4Bg);

        heartsCount = getIntent().getIntExtra("HEARTS_COUNT", level1.currentHearts);
        level1.currentHearts = heartsCount;
        updateHeartsDisplay();

        if (btnBack != null) btnBack.setOnClickListener(v -> { SoundManager.getInstance(this).playClick(this); finish(); });

        setupOptionClick(btnOption1, 0);
        setupOptionClick(btnOption2, 1);
        setupOptionClick(btnOption3, 2);
        setupOptionClick(btnOption4, 3);

        if (btnNext != null) {
            btnNext.setImageResource(R.drawable.btn_next_inactive);
            btnNext.setOnClickListener(v -> {
                if (selectedOptionIndex == -1) {
                    Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (selectedOptionIndex == correctAnswerIndex) {
                    SoundManager.getInstance(this).playCorrect(this);
                    Intent intent = new Intent(level4question1.this, level4question2.class);
                    intent.putExtra("HEARTS_COUNT", level1.currentHearts);
                    startActivity(intent);
                    finish();
                } else {
                    SoundManager.getInstance(this).playIncorrect(this);
                    if (level1.currentHearts > 1) {
                        level1.currentHearts--;
                        heartsCount = level1.currentHearts;
                        updateHeartsDisplay();
                        Toast.makeText(this, "Incorrect! Try again.", Toast.LENGTH_SHORT).show();
                    } else {
                        level1.currentHearts = 0;
                        heartsCount = 0;
                        updateHeartsDisplay();
                        showLevelLoseDialog();
                    }
                }
            });
        }
    }

    private void updateHeartsDisplay() {
        if (ivHearts != null && heartsCount >= 0 && heartsCount < heartsDrawables.length) {
            ivHearts.setImageResource(heartsDrawables[heartsCount]);
        }
    }

    private void setupOptionClick(RelativeLayout optionBtn, int index) {
        if (optionBtn != null) {
            optionBtn.setOnClickListener(v -> {
                SoundManager.getInstance(this).playClick(this);
                selectedOptionIndex = index;
                if (ivOption1Bg != null) ivOption1Bg.setImageResource(index == 0 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                if (ivOption2Bg != null) ivOption2Bg.setImageResource(index == 1 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                if (ivOption3Bg != null) ivOption3Bg.setImageResource(index == 2 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                if (ivOption4Bg != null) ivOption4Bg.setImageResource(index == 3 ? R.drawable.bg_option_btn : R.drawable.bg_option_not_chosen);
                if (btnNext != null) btnNext.setImageResource(R.drawable.btn_next);
            });
        }
    }

    private void showLevelLoseDialog() {
        android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.setContentView(R.layout.dialog_level_lose);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        ImageButton btnLosePlayAgain = dialog.findViewById(R.id.btnLosePlayAgain);
        ImageButton btnLoseReturnHome = dialog.findViewById(R.id.btnLoseReturnHome);
        if (btnLosePlayAgain != null) btnLosePlayAgain.setOnClickListener(v -> { level1.currentHearts = 3; startActivity(new Intent(this, level4.class)); finish(); });
        if (btnLoseReturnHome != null) btnLoseReturnHome.setOnClickListener(v -> { level1.currentHearts = 3; startActivity(new Intent(this, pythonlanguage.class)); finish(); });
        dialog.show();
    }
}
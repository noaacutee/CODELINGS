import java.io.*;
import java.nio.file.*;
import java.util.*;

public class ExtractPdf {
    public static void main(String[] args) throws Exception {
        byte[] data = Files.readAllBytes(Paths.get("C:/Users/daniel joshua madrid/.gemini/antigravity/brain/3b4ab34b-cece-44d1-8582-2fc10734e7b0/.user_uploaded/media_1790692661202.pdf"));
        String str = new String(data, "ISO-8859-1");
        System.out.println("PDF length: " + data.length);
        
        // Find streams
        int idx = 0;
        int streamCount = 0;
        while ((idx = str.indexOf("stream", idx)) != -1) {
            // Find endstream
            int end = str.indexOf("endstream", idx);
            if (end != -1) {
                // look before stream for dictionary
                int dictStart = str.lastIndexOf("<<", idx);
                String dict = dictStart != -1 ? str.substring(dictStart, idx) : "";
                System.out.println("Stream " + (++streamCount) + " at " + idx + ", dict: " + dict.replaceAll("\\s+", " "));
                
                // save raw stream content
                int streamStart = idx + 6;
                if (data[streamStart] == '\r') streamStart++;
                if (data[streamStart] == '\n') streamStart++;
                
                int streamEnd = end;
                while (streamEnd > streamStart && (data[streamEnd - 1] == '\r' || data[streamEnd - 1] == '\n')) {
                    streamEnd--;
                }
                
                byte[] streamBytes = Arrays.copyOfRange(data, streamStart, streamEnd);
                Files.write(Paths.get("stream_" + streamCount + ".bin"), streamBytes);
                idx = end + 9;
            } else {
                break;
            }
        }
    }
}

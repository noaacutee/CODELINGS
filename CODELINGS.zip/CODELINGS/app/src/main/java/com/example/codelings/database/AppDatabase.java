package com.example.codelings.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {User.class, LanguageTrack.class, UserProgress.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    // Define abstract methods for your DAOs
    public abstract UserDao userDao();
    public abstract LanguageTrackDao languageTrackDao();
    public abstract UserProgressDao userProgressDao();

    // Singleton instance to prevent opening multiple database instances at once
    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "codelings_database")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
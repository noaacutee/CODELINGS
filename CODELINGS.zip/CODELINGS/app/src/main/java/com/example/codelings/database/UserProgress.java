package com.example.codelings.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "user_progress")
public class UserProgress {

    @PrimaryKey(autoGenerate = true)
    private int progressId;

    private int userId;
    private int languageId;
    private int levelId;
    private boolean isUnlocked;
    private boolean isCompleted;
    private int starsEarned;

    public UserProgress(int userId, int languageId, int levelId, boolean isUnlocked, boolean isCompleted, int starsEarned) {
        this.userId = userId;
        this.languageId = languageId;
        this.levelId = levelId;
        this.isUnlocked = isUnlocked;
        this.isCompleted = isCompleted;
        this.starsEarned = starsEarned;
    }

    public int getProgressId() { return progressId; }
    public void setProgressId(int progressId) { this.progressId = progressId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getLanguageId() { return languageId; }
    public void setLanguageId(int languageId) { this.languageId = languageId; }

    public int getLevelId() { return levelId; }
    public void setLevelId(int levelId) { this.levelId = levelId; }

    public boolean isUnlocked() { return isUnlocked; }
    public void setUnlocked(boolean unlocked) { isUnlocked = unlocked; }

    public boolean isCompleted() { return isCompleted; }
    public void setCompleted(boolean completed) { isCompleted = completed; }

    public int getStarsEarned() { return starsEarned; }
    public void setStarsEarned(int starsEarned) { this.starsEarned = starsEarned; }
}
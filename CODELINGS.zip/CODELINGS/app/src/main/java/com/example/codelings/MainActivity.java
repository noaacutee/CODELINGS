package com.example.codelings;

import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

import com.example.codelings.database.AppDatabase;
import com.example.codelings.database.LanguageTrack;
import com.example.codelings.database.LanguageTrackDao;
import com.example.codelings.database.User;
import com.example.codelings.database.UserDao;
import com.example.codelings.database.UserProgress;
import com.example.codelings.database.UserProgressDao;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Get the database instance and DAOs
        AppDatabase db = AppDatabase.getDatabase(getApplicationContext());
        UserDao userDao = db.userDao();
        LanguageTrackDao trackDao = db.languageTrackDao();
        UserProgressDao progressDao = db.userProgressDao();

        // 2. Run database tasks safely on a background thread
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(new Runnable() {
            @Override
            public void run() {
                // --- Handle User ---
                User existingUser = userDao.getFirstUser();
                int currentUserId;
                if (existingUser == null) {
                    User newUser = new User("CoderJoe", 100, 3, 5);
                    userDao.insertUser(newUser);
                    currentUserId = userDao.getFirstUser().getUserId();
                    Log.d("DatabaseTest", "Default user inserted!");
                } else {
                    currentUserId = existingUser.getUserId();
                    Log.d("DatabaseTest", "Welcome back, " + existingUser.getUsername() + "!");
                }

                // --- Handle Language Tracks ---
                if (trackDao.getAllLanguageTracks().isEmpty()) {
                    trackDao.insertLanguageTrack(new LanguageTrack("Python", "Learn Python syntax and loops."));
                    trackDao.insertLanguageTrack(new LanguageTrack("Java Fundamentals", "Learn OOP and Java basics."));
                    Log.d("DatabaseTest", "Language tracks initialized!");
                }

                // --- Handle Initial User Progress ---
                UserProgress levelOneProgress = progressDao.getSpecificLevelProgress(currentUserId, 1, 1);
                if (levelOneProgress == null) {
                    UserProgress initialProgress = new UserProgress(currentUserId, 1, 1, true, false, 0);
                    progressDao.insertOrUpdateProgress(initialProgress);
                    Log.d("DatabaseTest", "Level 1 unlocked for user!");
                }
            }
        });
    }
}
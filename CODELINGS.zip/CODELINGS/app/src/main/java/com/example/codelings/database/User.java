package com.example.codelings.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")
public class User {

    @PrimaryKey(autoGenerate = true)
    private int userId;

    private String username;
    private int totalScore;
    private int streakCount;
    private int heartsRemaining;


    public User(String username, int totalScore, int streakCount, int heartsRemaining) {
        this.username = username;
        this.totalScore = totalScore;
        this.streakCount = streakCount;
        this.heartsRemaining = heartsRemaining;
    }

    public int getUserId() { return userId;}
    public void setUserId(int userId) { this.userId = userId; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public int getTotalScore() { return totalScore; }
    public void setTotalScore(int totalScore) { this.totalScore = totalScore; }

    public int getStreakCount() { return streakCount; }
    public void setStreakCount(int streakCount) {this.streakCount = streakCount; }

    public int getHeartsRemaining() { return heartsRemaining; }
    public void setHeartsRemaining(int heartsRemaining) {this.heartsRemaining = heartsRemaining; }
}
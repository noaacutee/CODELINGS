package com.example.codelings.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface LanguageTrackDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertLanguageTrack(LanguageTrack languageTrack);

    @Query("SELECT * FROM language_tracks")
    List<LanguageTrack> getAllLanguageTracks();

    @Query("SELECT * FROM language_tracks WHERE languageId = :languageId")
    LanguageTrack getLanguageTrackById(int languageId);
}
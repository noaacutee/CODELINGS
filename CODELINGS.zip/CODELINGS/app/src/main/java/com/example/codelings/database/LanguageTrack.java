package com.example.codelings.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "language_tracks")
public class LanguageTrack {

    @PrimaryKey(autoGenerate = true)
    private int languageId;

    private String languageName;
    private String description;


    public LanguageTrack(String languageName, String description) {
        this.languageName = languageName;
        this.description = description;
    }

    public int getLanguageId() { return languageId; }
    public void setLanguageId(int languageId) { this.languageId = languageId; }

    public String getLanguageName() { return languageName; }
    public void setLanguageName(String languageName) { this.languageName = languageName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
package com.example.codelings.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface UserProgressDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertOrUpdateProgress(UserProgress userProgress);

    @Update
    void updateProgress(UserProgress userProgress);


    @Query("SELECT * FROM user_progress WHERE userId = :userId AND languageId = :languageId")
    List<UserProgress> getUserProgressForLanguage(int userId, int languageId);


    @Query("SELECT * FROM user_progress WHERE userId = :userId AND languageId = :languageId AND levelId = :levelId")
    UserProgress getSpecificLevelProgress(int userId, int languageId, int levelId);
}